/****************************************************************
 * @file            main.c
 * @school          �ϲ����մ�ѧ��ʮ����ȫ����ѧ�����ܳ�����˫��������
 * @author          LYF/OREO
 * @version         v2.0
 * @Software        KEIL
 * @Target core     MM32F3277G
 * @date            2021-3-19
****************************************************************/
#include "headfile.h"
int main(void)
{
	int ui_flag =1;
	//ϵͳ��ʼ��
	System_Init();
	while(!(ui_flag==1 && KEY_Read(BKEY4)==0))
	{
		menu(ui_flag);
		if(KEY_Read(BKEY3)==0)
		{
			systick_delay_ms(50);
			if(KEY_Read(BKEY3)==0)
			{
				if(ui_flag==7)
                	ui_flag=1;
            	else
                	ui_flag++;
				
            	oled_fill(0x00);
           	}
            while(KEY_Read(BKEY3)==0);
        }	
	}
	Pare_Save();
	Final_data_save();
	if(Road_Integrals.Test_Mode==1) Road_Integrals.All_Distance=0;
	BEEP_Ctrl(2,50);
	oled_fill(0x00);
	//Get_Start_Flag();
	psInductance->ThreeFlag=3;
	GPIO_PWM_Init();
	thread_interrept();
	while(1)
	{
		
	}
}
