/****************************************************************
 * @file            thread.c
 * @school          �ϲ����մ�ѧ��ʮ����ȫ����ѧ�����ܳ�����˫��������
 * @author          LYF/OREO
 * @version         v2.0
 * @Software        KEIL
 * @Target core     MM32F3277G
 * @date            2021-3-19
****************************************************************/
#include "thread.h"
#include "headfile.h"
GYRO_VAR gyroscope;
CON_VAR con_var;
#define SPEED_FILTER  5	// ���ٶȼ��˲����
int32 speed_data_filtering[SPEED_FILTER+1];
//////////////////////�˵�����///////////////////////
int Turn_Speed = 124;  	   //ת���ٶ� 
int angle_min = 9100;	   //��С�Ƕ� 9100 
int angle_max = 10000;      //���Ƕ� 10000 
int three_turn_speed=120;  //��������ת���ٶ� 
void task_2ms(void)
{
	//IMU���ݲɼ�
	Get_Imu_data(); 
    //���ֵ�ɼ�
	InductanceMeasure(psInductance);
}
void task_4ms(void)
{
    //���ٶȻ�
    con_var.theory_duty += -PID_Increase(&s_pid.ang_vel_pid, erect_ang_vel, (int32)(gyroscope.Gyro_Balance*10),(int32)(gyroscope.target_angle_vel_y));
    con_var.theory_duty = limit_ab(con_var.theory_duty, -850, 850);
    //ת����ٶȻ�
    con_var.turn_duty = PID_Position(&s_pid.turn_vel_pid, erect_direct_vel, (gyroscope.Gyro_Turn+4),(con_var.radius*con_var.turn_speed_min));//65
    con_var.turn_duty = limit_ab(con_var.turn_duty, -1200, 1200);
    //ת�򻷵����˲�
    con_var.turn_duty_last = con_var.turn_duty_last*0.3 + con_var.turn_duty*0.7;
    //��������
    if(psInductance->ThreeFlag==3)
    {
        s_motor.left.duty = (0*con_var.theory_duty-1*con_var.turn_duty_last);
        s_motor.right.duty = (0*con_var.theory_duty+1*con_var.turn_duty_last);

    }
    else
    {
        s_motor.left.duty = (-1*con_var.theory_duty-1*con_var.turn_duty_last);
        s_motor.right.duty = (-1*con_var.theory_duty+1*con_var.turn_duty_last);
    }
    //���Ƶ��
	if(psInductance->Out_Flag==1)
		MotorOUT(0,0);
	else
		MotorOUT(s_motor.left.duty,s_motor.right.duty);
}
void task_8ms(void)
{	
    //��̬����
    Get_Angle(2);
    //����
    encoder_check();
    //�������
    con_var.car_distance += ((float)s_motor.speed.now / 30.0f);//��������2850
    //����ģʽ��������ʽ��������
	if(Road_Integrals.ALL_FLAG==2)
    {
        if(Road_Integrals.Test_Mode==1)
            Road_Integrals.All_Distance   += ((float)s_motor.speed.now / 20.0f);
        else
            Road_Integrals.Actual_Distance+= ((float)s_motor.speed.now / 20.0f);
    }	
	//�ٶȻ����˲�
	con_var.turn_speed_min = data_filtering(speed_data_filtering, s_motor.speed.now,SPEED_FILTER);
	//��Сת���ٶ��޷� ת�����
    //����
	if(psInductance->ThreeFlag==1)
		con_var.turn_speed_min = limit_ab(con_var.turn_speed_min, three_turn_speed, three_turn_speed+1);
    else if(Road_Integrals.SSSS_flag==1)
        con_var.turn_speed_min = limit_ab(con_var.turn_speed_min, 60, 120);
    //������
	else if(psInductance->RoundFlag!=0 && psInductance->RoundFlag!=5)
		con_var.turn_speed_min = limit_ab(con_var.turn_speed_min, 75, Turn_Speed);    
	else 
    //����Ѳ��
		con_var.turn_speed_min = limit_ab(con_var.turn_speed_min, 50, Turn_Speed); 
    
    //ת�� ��Ⱥ� �⻷
    if(psInductance->RoundFlag==3 || psInductance->RoundFlag==4 || psInductance->RoundFlag==5)
        con_var.radius = PID_PositionDynamic(&s_pid.turn_pid, erect_turn[2],psInductance->dir, 0);
    else
	    con_var.radius = PID_PositionDynamic(&s_pid.turn_pid, erect_turn[0],psInductance->dir, 0);

    if(psInductance->RoundFlag!=0 )
    {
        if(psInductance->Small_Round_Flag==1)
        {
            con_var.radius = limit_ab(con_var.radius,-60,60 );//55
        }
        else
        {
            con_var.radius = limit_ab(con_var.radius,-55,55 );//55
        }
    }
    else
        con_var.radius = limit_ab(con_var.radius,-60,60);//60
    //ֱ�� �Ƕ� �⻷
    if(Road_Integrals.SSSS_flag==1)
        gyroscope.target_angle_vel_y = PID_Position(&s_pid.angle_pid, ramp_erect_angle, (gyroscope.Balance_Angle)*100,gyroscope.target_angle_y);
    else
        gyroscope.target_angle_vel_y = PID_Position(&s_pid.angle_pid, erect_angle, (gyroscope.Balance_Angle)*100,gyroscope.target_angle_y);
    //����޷�
    gyroscope.target_angle_vel_y = limit_ab(gyroscope.target_angle_vel_y, -1500, 1500);
}
void task_20ms(void)
{
	Flag_Check();
	Calcarr[0]=Road_Integrals.All_Distance; //ȫ��·��
    Calcarr[1]=gyroscope.Balance_Angle;     //ֱ���Ƕ�
	Calcarr[2]=gyroscope.Gyro_Turn;         //ת����ٶ�
	Calcarr[3]=Road_Integrals.angle;
	Calcarr[4]=s_motor.speed.now;	
    Calcarr[5]=s_motor.speed.set;	
	Calcarr[6]=psInductance->InductanceAveNowA + psInductance->InductanceAveNowB +psInductance->InductanceAveNowC +psInductance->InductanceAveNowD +psInductance->InductanceAveNowE;
	Calcarr[7]=psInductance->InductanceAveNowC;
	send_to_computer();
}
void task_40ms(void)
{		
	//�ٶȻ�
    gyroscope.target_angle_y = -PID_Position(&s_pid.speed_pid, erect_speed, s_motor.speed.now, s_motor.speed.set);
    gyroscope.target_angle_y += 10000;//10000
    if(psInductance->RampFlag!=0)
	    gyroscope.target_angle_y = limit_ab(gyroscope.target_angle_y,9300,9800);
    else
        gyroscope.target_angle_y = limit_ab(gyroscope.target_angle_y, angle_min, angle_max);
}

//������Ⱥ���
static schedule_task_t schedule_task[] =
{
    {task_2ms, 2, 2, 0},//task_2ms(�������� 2ִ������ 2��ʼ����ʱ�� 0 ����ִ�б�־
    {task_4ms, 4, 4, 0},
    {task_8ms, 8,  8, 0},
    {task_20ms, 20,  20, 0},
    {task_40ms, 40, 40, 0}
};

#define TASK_NUM (sizeof(schedule_task)/sizeof(schedule_task_t))
	
void task_interrupt(void)  
{
    unsigned char index = 0;
    for (index = 0; index < TASK_NUM; index++)
    {
        if (schedule_task[index].run_timer)
        {
            schedule_task[index].run_timer--;
            if (0 == schedule_task[index].run_timer)
            {
                schedule_task[index].run_timer = schedule_task[index].interval_time;
                schedule_task[index].run_sign = 1;
            }
        }
    }
}

void task_process(void)
{
    unsigned char index = 0;

    for (index = 0; index < TASK_NUM; index++)
    {
        if (schedule_task[index].run_sign)        
        {
            schedule_task[index].run_sign = 0;
            schedule_task[index].task_func();
        }
    }
}

int limit_ab(int x, int a, int b)
{
    if(x<a) x = a;
    if(x>b) x = b;
    return x;
}
