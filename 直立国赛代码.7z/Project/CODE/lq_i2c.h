/****************************************************************
 * @file            lq i2c.h
 * @school          �ϲ����մ�ѧ��ʮ����ȫ����ѧ�����ܳ�����˫��������
 * @author          LYF/OREO
 * @version         v2.0
 * @Software        KEIL
 * @Target core     MM32F3277G
 * @date            2021-3-19
****************************************************************/
#ifndef _lq_i2c_H_
#define _lq_i2c_H_
#include "stdint.h"
#define VL53_SCL	A10															// ����SCL����  ���������Ϊ����IO
#define VL53_SDA	A9
#define SDA_IN         gpio_dir(VL53_SDA,GPI,GPI_PULL_UP);
#define SDA_OUT        gpio_dir(VL53_SDA,GPO,GPO_PUSH_PULL);

#define IIC_SCL_H      gpio_set(VL53_SCL, 1);
#define IIC_SCL_L      gpio_set(VL53_SCL, 0);

#define IIC_SDA_H      gpio_set(VL53_SDA, 1);
#define IIC_SDA_L      gpio_set(VL53_SDA, 0);

#define IIC_SDA_READ   gpio_get(VL53_SDA)
void IIC_Init(void);                      
uint8_t IIC_ReadByteFromSlave(uint8_t I2C_Addr,uint8_t reg,uint8_t *buf);
uint8_t IIC_ReadMultByteFromSlave(uint8_t dev, uint8_t reg, uint8_t length, uint8_t *data);
uint8_t IIC_WriteByteToSlave(uint8_t I2C_Addr,uint8_t reg,uint8_t buf);
uint8_t IIC_WriteMultByteToSlave(uint8_t dev, uint8_t reg, uint8_t length, uint8_t* data);

#endif