#ifndef _SYS_INIT_h
#define _SYS_INIT_h
extern int speed_init;
extern void System_Init(void);
extern void GPIO_PWM_Init(void);
extern void Get_Start_Flag(void);
extern void Flag_Check(void);
extern void Pare_Save(void);
extern void Pare_Read(void);
extern void Final_data_read(void);
extern void Final_data_save(void);
#endif