/****************************************************************
 * @file            PID.c
 * @school          �ϲ����մ�ѧ��ʮ����ȫ����ѧ�����ܳ�����˫��������
 * @author          LYF/OREO
 * @version         v2.0
 * @Software        KEIL
 * @Target core     MM32F3277G
 * @date            2021-3-19
****************************************************************/
#include "PID.h"
#include "headfile.h"
PID_ERECT s_pid;

//�ٶȻ� �⻷
float erect_speed[5] = {40, 0,5, 0, 0};//35 5
//�ǶȻ� �⻷
float erect_angle[5] = {0.5, 0, 0.01, 0, 0};//0.5 0.01 
//�µ��ǶȻ� �⻷
float ramp_erect_angle[5] = {2, 0, 0.5, 0, 0};//0.3 0.01 
//���ٶ�ֱ�� �ڻ�
float erect_ang_vel[5] = {0.2, 0.015, 0, 0, 0};//0.2  0.02
//���ٶȷ��� �ڻ�
float erect_direct_vel[5] = {0.155,  0, 0.3, 0, 0};//0.155   0.25
//���� �⻷
float erect_turn[5][5] = {{1.2,  0, 0.8, 250, 0},  //1.2 0.8 250 
                          {1.1,  0, 3, 650, 0},
                          {1.2,  0, 0.8, 250, 0}}; //����	1.2 0.8 250//��̬λ��ʽPID
int PID_PositionDynamic(PID_INFO *pid_info, float * PID_Parm, float NowPoint, float SetPoint)
{
    int Actual;
    float Kp;

    pid_info->iError = (int)(SetPoint - NowPoint);

    Kp = ((1.0*(pid_info->iError * pid_info->iError))*1/ PID_Parm[KT]) + PID_Parm[KP];

    Actual = Kp * pid_info->iError  +
        PID_Parm[KD] * ((0.8*pid_info->iError + 0.2*pid_info->LastError) - pid_info->LastError);

    pid_info->LastError = pid_info->iError;


    return Actual;
}

/*
λ��ʽPID
*/
int PID_Position(PID_INFO *pid_info, float *PID_Parm, float NowPoint, float SetPoint)
{
    int Position;

    pid_info->iError = (int)(SetPoint - NowPoint);      

    Position = PID_Parm[KP] * pid_info->iError +
        PID_Parm[KI] * pid_info->SumError +
            PID_Parm[KD] * (pid_info->iError - pid_info->LastError);

    pid_info->PrevError = pid_info->LastError;
    pid_info->LastError = pid_info->iError;   
    pid_info->LastData = NowPoint;            

    return Position;
}

/*
����ʽPID
*/
int PID_Increase(PID_INFO *pid_info, float *PID_Parm, int NowPoint, int SetPoint)
{
    int Increase;

    pid_info->iError = SetPoint - NowPoint;

    Increase = PID_Parm[KP] * (pid_info->iError - pid_info->LastError) +
        PID_Parm[KI] * pid_info->iError +
            PID_Parm[KD] * (pid_info->iError - 2*pid_info->LastError + pid_info->PrevError);
	
    pid_info->PrevError = pid_info->LastError;
    pid_info->LastError = pid_info->iError;
    pid_info->LastData = NowPoint;

    return Increase;
}
/*
PID������ʼ��
*/
void pid_para_init(PID_INFO *pid_info)
{
    pid_info->iError = 0;
    pid_info->SumError = 0;
    pid_info->PrevError = 0;
    pid_info->LastError = 0;
    pid_info->LastData = 0;
}
