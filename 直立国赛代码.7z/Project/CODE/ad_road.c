/****************************************************************
 * @file            ad_road.c
 * @school          �ϲ����մ�ѧ��ʮ����ȫ����ѧ�����ܳ�����˫��������
 * @author          LYF/OREO
 * @version         v2.0
 * @Software        KEIL
 * @Target core     MM32F3277G
 * @date            2021-3-19
****************************************************************/
#include "ad_road.h"
#include "headfile.h"
#include <stdlib.h>
#define 	ElcetMAX_A                 2500      
#define 	ElcetMAX_B                 2000     
#define 	ElcetMAX_C                 2400     
#define 	ElcetMAX_D                 2000      
#define 	ElcetMAX_E                 2500     
#define 	InductanceCount            20     
//�󻷲���
int BWAITENDISTANCE = 				2100;				//�̶��������  �����ӳ��뻷    
int BSTRONGERDISTANCE = 			800;  			//ǿ�ƴ�Ǿ���
int BSTRONGCIRCLE = 					-40;        //ǿ�ƽǶ�
int BWAITOUUTROUND= 					60;				  //�󻷵Ⱥ��ʱ��
//С������
int SWAITENDISTANCE = 			 1000;			  //�̶��������  �����ӳ��뻷 
int SSTRONGERDISTANCE = 			900;  			//ǿ�ƴ�Ǿ���
int SSTRONGCIRCLE = 					 50;        //ǿ�ƽǶ� 80    ǿ�ƽǶ�����Ҫ�Ӳ˵��� ������ʱ���Ŵ�̫����
int SWAITOUUTROUND =       	 1000;			  //С���Ⱥ��ʱ��  ������Ҫ�ĳ� 2s��ֹ����
//��������
int ROUND1_DIR =-1;  											//��һ�����ķ��� -1 L 1 R
int ROUND2_DIR =-1;												//�ڶ������ķ��� -1 L 1 R
int ROUND1_MODE = 0;											//��һ�����Ĵ�С  0 S 1 B
int ROUND2_MODE = 0;											//�ڶ������Ĵ�С  0 S 1 B
int ROUND_GO_FLAG=1;											//�Ƿ����
int ROUND_GO_EVERY=0;											//ѭ������
int ROUND_NUM = 0;												//��������
int ROUND_SPEED = 124;										//�����ٶ�
int ROUNDCOLDCOUNT  =	3300;			          //���������ȴ���� 3000
int Round_Threshold =	14000;			        //�������ֵ
//����·�ڲ���
int CrossRoad_Dir					  = 1;					//����������
int CrossRoad_Angle 				= 30000;			//�ǶȻ�����
int CrossRoad_STRONG_DIR 		= 45;				  //ǿ��ERROR
int CrossRoad_STOP_DISTANCE = 3500;				//����ͣ������
int CrossRoad_Threshold = 5700;				    //���������ֵ
int CrossRoad_Distance = 3000;            //�ڶ������������� 3000���� �ֳ����� 
//�����������ӵĲ���
int CrossRoad_Num=0;                      //�����ľ�������
int CrossRoad1_Distance=1500;             //��һ��������� 1500 ����
//�µ�����
int RAMPDISTANCE		  = 2800;							//�µ�����
//�������ݼ�¼����
#define DATA_SIZE		1024/sizeof(uint32)   //���ݳ���
uint32 Integal_data_buffer[DATA_SIZE];    //�������뻺����


Road_Integral Road_Integrals;
static Inductance sInductance; 

Inductance *psInductance = &sInductance;
void Round_Processing(float ROUND_DIR,int round_mode);
void three_processing(void);
void Ramp_processing(void);
void Car_Protect(void);
void out_process(void);
/*
��ʼ��ADC�ɼ�
*/
void My_ADC_Init(void)
{
	adc_init(ADC_2,ADC2_CH04_A04,ADC_12BIT);
	adc_init(ADC_2,ADC2_CH05_A05,ADC_12BIT);
	adc_init(ADC_2,ADC2_CH06_A06,ADC_12BIT);
	adc_init(ADC_2,ADC2_CH07_A07,ADC_12BIT);
	adc_init(ADC_3,ADC3_CH10_C00,ADC_12BIT);
}
extern void TwoUnNumSwap(uint16 *a, uint16 *b)  
{
  uint16 temp  = *a;
  *a = *b;
  *b = temp;
}

int UnQuickSort(uint16	*array, const int maxlen, const int begin, const int end)  
{  
	
    int i = 0, j = 0;
    if(begin < end)  
    {
        i = begin + 1;  
        j = end;        
        while(i < j)
        {  
            if(*(array + i) > *(array + begin))   
            {  
                TwoUnNumSwap(array + i, array + j);   
                j--;  
            }
            else  
            {
                i++;  
            }
        }
        if(*(array + i) >= *(array + begin)) 
        {  
            i--;  
        }  
        TwoUnNumSwap(array + begin, array + i);  	   
        UnQuickSort(array, maxlen, begin, i);  
        UnQuickSort(array, maxlen, j, end);		
		return true;
    }
	else
	  return false;
}

float InductanceMeasure(Inductance *psInductance)
{
  for(int i=0;i<20;i++)
  {
    psInductance->InductanceNowA[i] = adc_convert(ADC_2,ADC2_CH04_A04);  
    psInductance->InductanceNowB[i] = adc_convert(ADC_2,ADC2_CH05_A05);   
    psInductance->InductanceNowC[i] = adc_convert(ADC_2,ADC2_CH06_A06);  
    psInductance->InductanceNowD[i] = adc_convert(ADC_2,ADC2_CH07_A07);   
    psInductance->InductanceNowE[i] = adc_convert(ADC_3,ADC3_CH10_C00);  
  }
  
  UnQuickSort(psInductance->InductanceNowA,20,0,InductanceCount);
  UnQuickSort(psInductance->InductanceNowB,20,0,InductanceCount);
  UnQuickSort(psInductance->InductanceNowC,20,0,InductanceCount);
  UnQuickSort(psInductance->InductanceNowD,20,0,InductanceCount);
  UnQuickSort(psInductance->InductanceNowE,20,0,InductanceCount);

  for(int i = 7;i <= 14;i++)
  { 
    psInductance->InductanceSumA+=psInductance->InductanceNowA[i];
    psInductance->InductanceSumB+=psInductance->InductanceNowB[i];
    psInductance->InductanceSumC+=psInductance->InductanceNowC[i];
    psInductance->InductanceSumD+=psInductance->InductanceNowD[i];
    psInductance->InductanceSumE+=psInductance->InductanceNowE[i];
  }

  psInductance->InductanceAveNowA = psInductance->InductanceSumA/8;
  psInductance->InductanceAveNowB = psInductance->InductanceSumB/8;
  psInductance->InductanceAveNowC = psInductance->InductanceSumC/8;
  psInductance->InductanceAveNowD = psInductance->InductanceSumD/8;
  psInductance->InductanceAveNowE = psInductance->InductanceSumE/8;

  if(psInductance->InductanceAveNowA>psInductance->InductanceAveMAXA)
    psInductance->InductanceAveMAXA=psInductance->InductanceAveNowA;
  if(psInductance->InductanceAveNowB>psInductance->InductanceAveMAXB)
    psInductance->InductanceAveMAXB=psInductance->InductanceAveNowB;
  if(psInductance->InductanceAveNowC>psInductance->InductanceAveMAXC)
    psInductance->InductanceAveMAXC=psInductance->InductanceAveNowC;
  if(psInductance->InductanceAveNowD>psInductance->InductanceAveMAXD)
    psInductance->InductanceAveMAXD=psInductance->InductanceAveNowD;
  if(psInductance->InductanceAveNowE>psInductance->InductanceAveMAXE)
    psInductance->InductanceAveMAXE=psInductance->InductanceAveNowE;

  if(psInductance->InductanceAveMAXA>ElcetMAX_A)
    psInductance->InductanceAveMAXA = ElcetMAX_A-400;
  if(psInductance->InductanceAveMAXB>ElcetMAX_B)
    psInductance->InductanceAveMAXB = ElcetMAX_B-500;
  if(psInductance->InductanceAveMAXC>ElcetMAX_C)
    psInductance->InductanceAveMAXC = ElcetMAX_C-600;
  if(psInductance->InductanceAveMAXD>ElcetMAX_D)
    psInductance->InductanceAveMAXD = ElcetMAX_D-500;
  if(psInductance->InductanceAveMAXE>ElcetMAX_E)
    psInductance->InductanceAveMAXE = ElcetMAX_D-400;

  psInductance->InductanceGYHA=(float)(psInductance->InductanceAveNowA)/(float)(psInductance->InductanceAveMAXA)*1000;
  psInductance->InductanceGYHB=(float)(psInductance->InductanceAveNowB)/(float)(psInductance->InductanceAveMAXB)*1000;
  psInductance->InductanceGYHC=(float)(psInductance->InductanceAveNowC)/(float)(psInductance->InductanceAveMAXC)*1000;
  psInductance->InductanceGYHD=(float)(psInductance->InductanceAveNowD)/(float)(psInductance->InductanceAveMAXD)*1000;
  psInductance->InductanceGYHE=(float)(psInductance->InductanceAveNowE)/(float)(psInductance->InductanceAveMAXE)*1000;

  psInductance->InductanceSumA=0;
  psInductance->InductanceSumB=0;
  psInductance->InductanceSumC=0;
  psInductance->InductanceSumD=0;
  psInductance->InductanceSumE=0;
  psInductance->flag = (psInductance->InductanceGYHA >= psInductance->InductanceGYHE) ? 1 : 0;
	//dir5ΪAE+BD��Ⱥ�
	psInductance->dir5 = (psInductance->InductanceGYHA >= psInductance->InductanceGYHE) ? \
    (float)(psInductance->InductanceGYHA + psInductance->InductanceGYHB-psInductance->InductanceGYHE - psInductance->InductanceGYHD)/ \
      (float)(psInductance->InductanceGYHA+psInductance->InductanceGYHE+psInductance->InductanceGYHB+psInductance->InductanceGYHD)*100: \
        (float)(psInductance->InductanceGYHE+psInductance->InductanceGYHD-psInductance->InductanceGYHB-psInductance->InductanceGYHA)/\
					(float)(psInductance->InductanceGYHA+psInductance->InductanceGYHE+psInductance->InductanceGYHB+psInductance->InductanceGYHD)*100;
	//dirΪAE��Ⱥ�			
  psInductance->dir = (psInductance->InductanceGYHA >= psInductance->InductanceGYHE) ? \
    (float)(psInductance->InductanceGYHA-psInductance->InductanceGYHE)/ \
      (float)(psInductance->InductanceGYHA+psInductance->InductanceGYHE)*100: \
        (float)(psInductance->InductanceGYHE-psInductance->InductanceGYHA)/(float)(psInductance->InductanceGYHA+psInductance->InductanceGYHE)*100;
	//dir2ΪAD��Ⱥ�		
 psInductance->dir2 = (psInductance->InductanceGYHA >= psInductance->InductanceGYHD) ? \
    (float)(psInductance->InductanceGYHA-psInductance->InductanceGYHD)/ \
      (float)(psInductance->InductanceGYHA+psInductance->InductanceGYHD)*100: \
        (float)(psInductance->InductanceGYHD-psInductance->InductanceGYHA)/(float)(psInductance->InductanceGYHA+psInductance->InductanceGYHD)*100;
	//dir3ΪBE��Ⱥ�		
 psInductance->dir3 = (psInductance->InductanceGYHB >= psInductance->InductanceGYHE) ? \
    (float)(psInductance->InductanceGYHB-psInductance->InductanceGYHE)/ \
      (float)(psInductance->InductanceGYHB+psInductance->InductanceGYHE)*100: \
        (float)(psInductance->InductanceGYHE-psInductance->InductanceGYHB)/(float)(psInductance->InductanceGYHB+psInductance->InductanceGYHE)*100;			 

                          if(psInductance->flag)
                          {
                            psInductance->dir=-psInductance->dir;
                            psInductance->dir2=-psInductance->dir2;
                            psInductance->dir5=-psInductance->dir5;
                          }

                          psInductance->flag = psInductance->InductanceGYHB >= psInductance->InductanceGYHD ? 0 : 1;
   psInductance->dir1 = (psInductance->InductanceGYHB >=psInductance->InductanceGYHD ? \
     (float)(psInductance->InductanceGYHB -psInductance->InductanceGYHD)/ \
        (float)(psInductance->InductanceGYHB +psInductance->InductanceGYHD)*100: \
          (float)(psInductance->InductanceGYHD-psInductance->InductanceGYHB )/(float)(psInductance->InductanceGYHB +psInductance->InductanceGYHD)*100);
                          psInductance->dir = -psInductance->dir;
                          if(psInductance->flag)
                          {
                              psInductance->dir1 = -1*psInductance->dir1;
                          }
                          psInductance->dir1 = -1*psInductance->dir1;//-3.1
													psInductance->dir5 = -1*psInductance->dir5;//-3.1
													psInductance->dir2 = -1*psInductance->dir2;//-3.1
													psInductance->dir3 = -1*psInductance->dir3;//-3.1
                          if(ROUND_GO_FLAG==1)
                          {
                              if(ROUND_NUM==0)
                                  ;//Round_Processing(ROUND1_DIR,ROUND1_MODE);
                              //if(ROUND_NUM==1)//�˴�ע�ͻ�����ֹ������̬���� ����
                               //   Round_Processing(ROUND2_DIR,ROUND2_MODE);
                              if(ROUND_NUM==2)
                              {
                                  if(ROUND_GO_EVERY==1)
                                      ROUND_NUM=0;
                                  else
                                      ROUND_GO_FLAG=0;
                              }
                          }
													Ramp_processing();
													//Car_Protect();
                          out_process();
													three_processing();
                          return (psInductance->dir);
}
float angle_out=0;
void out_process(void)
{
  if(psInductance->out_park_flag==0)
  {
    psInductance->out_park_flag=1;
  }
  if(psInductance->out_park_flag==1)
	{//���ִ�һ���ĽǶȽ�����
			psInductance->dir = 45;
			angle_out += ((float)gyroscope.Gyro_Turn / 10.0f);
			if(fabs(angle_out)>30000)
			{
        psInductance->out_park_flag=2;
			}
	}
}
/*
 *  name:   �µ���⺯��
 *  para:   NONE
 *  return: NONE
 *  writer: LYF
 *  function:�µ����������ǻ����ټ���µ�
 *  time:   2021/7/7
 */
float Ramp_Distance=0;
float Ramp_finish=0;
void Ramp_processing(void)
{
	if(psInductance->RampFlag==0 && psInductance->RoundFlag==0 \
		&& psInductance->ThreeFlag ==0 && psInductance->start_flag==1 && con_var.car_distance >2400 && Ramp_finish==0)
		{
			psInductance->RampFlag=1;
      Ramp_finish=1;
		}
	if(psInductance->RampFlag==1)
	{
		Ramp_Distance += ((float)s_motor.speed.now / 10.0f);
		if(Ramp_Distance>RAMPDISTANCE)
		{
				psInductance->RampFlag=0;
				Ramp_Distance=0;
		}
	}
}

/*
 *  name:   ����·�ڼ�⺯��
 *  para:   NONE
 *  return: NONE
 *  writer: LYF
 *  function:���ֵ����
 *  time:   2021/5/21
 */
float three_distance=0;
float three_angle=0;
char uart1_get_buffer=0;
int put_flag=0;
int st_flag=0;
void three_processing(void)
{
   if(put_flag==0 && con_var.car_distance >CrossRoad1_Distance)
    {
      put_flag=1;
      uart_putchar(UART_1,'Y');
    }
	if(psInductance->start_flag==1)
	{
    if(psInductance->InductanceAveNowA\
		+psInductance->InductanceAveNowB\
		+psInductance->InductanceAveNowC\
		+psInductance->InductanceAveNowD\
			+psInductance->InductanceAveNowE\
		< CrossRoad_Threshold && con_var.car_distance >CrossRoad1_Distance && psInductance->ThreeFlag==0) 
		{	//�ж��Ƿ��ǲ���
			psInductance->ThreeFlag=1;
		}

		if(psInductance->ThreeFlag==1)
		{//���ִ�һ���ĽǶȽ�����
			psInductance->dir = CrossRoad_STRONG_DIR*CrossRoad_Dir;
			three_angle += ((float)gyroscope.Gyro_Turn / 10.0f);
			if(fabs(three_angle)>CrossRoad_Angle)
			{
				psInductance->ThreeFlag=2;
				three_angle=0;
			}
		}
    if(psInductance->ThreeFlag==2)//����ͣ���ȱ�־
		{//������ͣ�� �����ַ���
			three_distance += ((float)s_motor.speed.now / 10.0f);
			if(three_distance>CrossRoad_STOP_DISTANCE)
			{
				three_distance=0;
        psInductance->ThreeFlag=3;
			}
		}
    if(psInductance->ThreeFlag==3 && st_flag==0)
    {//�����ַ����ݸ��ҷ���
    /*
      my_uart_getchar(UART_1, &uart1_get_buffer);
      if(uart1_get_buffer == 'Y')
      {
        uart1_get_buffer=0;
        con_var.car_distance=0;
        ROUND_NUM=0;
        psInductance->ThreeFlag=0;
      }
    */
      if(s_motor.speed.now>5)
      {
        st_flag=1;
        uart1_get_buffer=0;
        con_var.car_distance=0;
        ROUND_NUM=0;
        psInductance->ThreeFlag=0;
      }
    }
	}
}

/*
 *  name:   ������⺯��
 *  para:   NONE
 *  return: NONE
 *  writer: LYF
 *  function:
 *  time:   2021/7/6
 */
float dis1=0;
void Round_Processing(float ROUND_DIR,int round_mode)
{
		int distance1;
		int distance2;
		float strong_dir;
		int wait_time;
		if(round_mode==0)
		{
			distance1 = SWAITENDISTANCE;
			distance2 = SSTRONGERDISTANCE;
			strong_dir = -SSTRONGCIRCLE*ROUND_DIR;
			wait_time = SWAITOUUTROUND;
      psInductance->Small_Round_Flag=1;
		}
		else
		{
			distance1 = BWAITENDISTANCE;
			distance2 = BSTRONGERDISTANCE;
			strong_dir = BSTRONGCIRCLE*ROUND_DIR;
			wait_time = BWAITOUUTROUND;
      psInductance->Small_Round_Flag=0;
		}
		if(psInductance->InductanceAveNowC > 2000\
			&& psInductance->InductanceAveNowA \
		+psInductance->InductanceAveNowB\
		+psInductance->InductanceAveNowC\
		+psInductance->InductanceAveNowD\
		+psInductance->InductanceAveNowE > Round_Threshold\
     &&psInductance->RoundFlag==0 && con_var.car_distance >100)//�м������ ��⵽������־λΪ2
     {
         psInductance->RoundFlag = 2;
     }
    if(psInductance->RoundFlag==2)
      {														//���ж��ܴ� ��⵽�뻷λ�� ��־λΪ3
        if(psInductance->InductanceAveNowA + psInductance->InductanceAveNowB +psInductance->InductanceAveNowC +psInductance->InductanceAveNowD +psInductance->InductanceAveNowE > Round_Threshold)
         {
						psInductance->RoundFlag = 3;
         }
      }
    if(psInductance->RoundFlag == 3 )
      {
						dis1 += ((float)s_motor.speed.now / 10.0f);
            if(dis1 < distance1)
              {//���־���׼���뻷
              }
            else if(dis1 < distance1+distance2)
              {//�̶������뻷���
                psInductance->dir = strong_dir;
              }
              else
              {//�����뻷 ��־λΪ4
									dis1=0;
                  psInductance->RoundCount = 0;
                  psInductance->RoundFlag = 4;
              }	
      }
    if(psInductance->RoundFlag == 4)
    {
        if(psInductance->RoundCount < wait_time)
         {//�ȴ�����
             psInductance->RoundCount++;
         
         }
        else if(psInductance->InductanceAveNowA + psInductance->InductanceAveNowB +psInductance->InductanceAveNowC +psInductance->InductanceAveNowD +psInductance->InductanceAveNowE > Round_Threshold)
        {//��⵽����ֵ�ϴ� �����ɹ� ��־λΪ5
							
              psInductance->RoundCount = 0;
              psInductance->RoundFlag = 5;
						if(ROUND_DIR==-1)
							psInductance->dir = psInductance->dir;
						else
							psInductance->dir = -psInductance->dir1;
        }
    }
    if(psInductance->RoundFlag == 5)
    {		
				dis1 += ((float)s_motor.speed.now / 10.0f);
        if(dis1< ROUNDCOLDCOUNT)
        {
						//���������ȴ
						if(ROUND_DIR==-1)
						psInductance->dir = psInductance->dir;
						else
						{
							if(round_mode==1)
								psInductance->dir = -psInductance->dir1;//
							else
								psInductance->dir = -psInductance->dir1;//
						}
        }
        else
        {
						//��ȴ���־����
						dis1=0;
            ROUND_NUM++;
            psInductance->RoundCount = 0;
            psInductance->RoundFlag = 0;
        }
    }
}

 /*
 *  name:   ��������
 *  para:   NONE
 *  return: NONE
 *  writer: LYF
 *  function:���ֵ����
 *  time:   2021/7/6
 */
void Car_Protect(void)
{
	if(psInductance->InductanceAveNowA\
		+psInductance->InductanceAveNowB\
		+psInductance->InductanceAveNowC\
		+psInductance->InductanceAveNowD\
			+psInductance->InductanceAveNowE\
		< 300 && psInductance->start_flag==1 && psInductance->RampFlag==0)
	{
		psInductance->Out_Flag=1;
	}
}

 /*
 *  name:   ����Ԫ��ȫ�̻���(����)
 *  para:   NONE
 *  return: NONE
 *  writer: LYF
 *  function:ȫ�̻��ּ�¼׼����������ĵ�
 *  time:   2021/7/6
 */
void Integral_All_Road(void)
{
  if(psInductance->InductanceAveNowA\
		+psInductance->InductanceAveNowB\
		+psInductance->InductanceAveNowC\
		+psInductance->InductanceAveNowD\
			+psInductance->InductanceAveNowE\
		> 7000 && psInductance->start_flag==1 &&con_var.car_distance >100)
	{
		Road_Integrals.ALL_FLAG=2;//�Ӳ��������˿�ʼ������ֵ
		
	}
	//��⻷��1
	if(Road_Integrals.Test_Mode==1 && Road_Integrals.ALL_FLAG==2 && psInductance->RoundFlag !=0 && ROUND_NUM==0 && Road_Integrals.Round1_finish==0)
	{
		Road_Integrals.Round1_Distance=Road_Integrals.All_Distance;
		Road_Integrals.Round1_finish=1;
	}
	//��⻷��2
	if(Road_Integrals.Test_Mode==1 && Road_Integrals.ALL_FLAG==2 && psInductance->RoundFlag !=0 && ROUND_NUM==1 && Road_Integrals.Round2_finish==0)
	{
		Road_Integrals.Round2_Distance=Road_Integrals.All_Distance;
		Road_Integrals.Round2_finish=1;
	}
	//����µ�
	if(Road_Integrals.Test_Mode==1 && Road_Integrals.Test_Mode==1 && Road_Integrals.ALL_FLAG==2 && psInductance->RampFlag!=0 && Road_Integrals.Ramp_finish==0)
	{
		Road_Integrals.Ramp_Distance=Road_Integrals.All_Distance;
		Road_Integrals.Ramp_finish=1;
	}
	//��⽵�ٵ�1
	if(Road_Integrals.Test_Mode==1 && Road_Integrals.ALL_FLAG==2 && !KEY_Read(BKEY1) && Road_Integrals.Dowm_Point1_finish==0)
  {
		Road_Integrals.Dowm_Point1_finish=1;
		Road_Integrals.Dowm_Dista1=Road_Integrals.All_Distance;
		oled_p6x8str(0,0,"Point1_Get!");
  }
	//��⽵�ٵ�2
	if(Road_Integrals.Test_Mode==1 && Road_Integrals.ALL_FLAG==2 && !KEY_Read(BKEY2) && Road_Integrals.Dowm_Point2_finish==0)
  {
		Road_Integrals.Dowm_Point2_finish=1;
		Road_Integrals.Dowm_Dista2=Road_Integrals.All_Distance;
		oled_p6x8str(0,1,"Point2_Get!");
  }
	//��⽵�ٵ�3
	if(Road_Integrals.Test_Mode==1 && Road_Integrals.ALL_FLAG==2 && !KEY_Read(BKEY3) && Road_Integrals.Dowm_Point3_finish==0)
  {
		Road_Integrals.Dowm_Point3_finish=1;
		Road_Integrals.Dowm_Dista3=Road_Integrals.All_Distance;
		oled_p6x8str(0,2,"Point3_Get!");
  }
  //���Сs
	if(Road_Integrals.Test_Mode==1 && Road_Integrals.ALL_FLAG==2 && !KEY_Read(BKEY4) && Road_Integrals.ssss_Point_finish==0)
  {
		Road_Integrals.ssss_Point_finish=1;
		Road_Integrals.Ssss_Distan=Road_Integrals.All_Distance;
		oled_p6x8str(0,3,"SSSS_Get!");
  }
	if(psInductance->InductanceAveNowA\
		+psInductance->InductanceAveNowB\
		+psInductance->InductanceAveNowC\
		+psInductance->InductanceAveNowD\
			+psInductance->InductanceAveNowE\
		< 4000 && Road_Integrals.ALL_FLAG==2 && psInductance->RoundFlag==0  && psInductance->RampFlag==0 && con_var.car_distance>CrossRoad_Distance)
	{
		Road_Integrals.ALL_FLAG=3;//�ֽ�������,ֹͣ����
    if(Road_Integrals.Test_Mode==1)
    {
      oled_p6x8str(0,0,"All_Dis:");
		  oled_printf_float(49,0,Road_Integrals.All_Distance,5,1);
		  oled_p6x8str(0,1,"Round1_Dis:");
		  oled_printf_float(67,1,Road_Integrals.Round1_Distance,5,1);
		  oled_p6x8str(0,2,"Round2_Dis:");
		  oled_printf_float(67,2,Road_Integrals.Round2_Distance,5,1);
		  oled_p6x8str(0,3,"Ramp_Dis:");
		  oled_printf_float(55,3,Road_Integrals.Ramp_Distance,5,1);
		  oled_p6x8str(0,4,"Down_Dis1:");
		  oled_printf_float(61,4,Road_Integrals.Dowm_Dista1,5,1);
		  oled_p6x8str(0,5,"Down_Dis2:");
		  oled_printf_float(61,5,Road_Integrals.Dowm_Dista2,5,1);
		  oled_p6x8str(0,6,"Down_Dis3:");
		  oled_printf_float(61,6,Road_Integrals.Dowm_Dista3,5,1);
		  oled_p6x8str(0,7,"SSSS_Dist:");
		  oled_printf_float(61,7,Road_Integrals.Ssss_Distan,5,1);
      //д��FLASH����
      Integal_data_buffer[2]=Road_Integrals.All_Distance;
      Integal_data_buffer[3]=Road_Integrals.Round1_Distance;
      Integal_data_buffer[4]=Road_Integrals.Round2_Distance;
      Integal_data_buffer[5]=Road_Integrals.Ramp_Distance;
      Integal_data_buffer[6]=Road_Integrals.Dowm_Dista1;
      Integal_data_buffer[7]=Road_Integrals.Dowm_Dista2;
      Integal_data_buffer[8]=Road_Integrals.Dowm_Dista3;
      Integal_data_buffer[9]=Road_Integrals.Ssss_Distan;
      flash_erase_page(FLASH_SECTION_127, FLASH_PAGE_0);
      flash_page_program(FLASH_SECTION_127, FLASH_PAGE_0, Integal_data_buffer, DATA_SIZE);
    }
	}
}