/****************************************************************
 * @file            menu.c
 * @school          �ϲ����մ�ѧ��ʮ����ȫ����ѧ�����ܳ�����˫��������
 * @author          LYF/OREO
 * @version         v2.0
 * @Software        KEIL
 * @Target core     MM32F3277G
 * @date            2021-3-19
****************************************************************/
#include "menu.h"
#include "headfile.h"
int count=0;
unsigned int round_flag = 0;
unsigned int option_flag = 0;
unsigned int pid_option_flag = 0;
unsigned int three_option_flag = 0;
unsigned int integal_option_flag = 0;
unsigned int integal_speed_option_flag = 0;
void menu(int flag)
{
    if(1)
    {
        InductanceMeasure(psInductance);
        if(flag==1)
        {
            count++;
            oled_p6x8str(0,0,"NCHU FRY EGGS TEAM");
            if(count>50)
            {
               oled_p6x8str(0,1,"A:");
               Oled_Print_float_num(12,1,psInductance->InductanceAveNowA);
               oled_p6x8str(0,2,"B:");
               Oled_Print_float_num(12,2,psInductance->InductanceAveNowB);
               oled_p6x8str(0,3,"C:");
               Oled_Print_float_num(12,3,psInductance->InductanceAveNowC);
               oled_p6x8str(0,4,"D:");
               Oled_Print_float_num(12,4,psInductance->InductanceAveNowD);
               oled_p6x8str(0,5,"E:");
               Oled_Print_float_num(12,5,psInductance->InductanceAveNowE);
               oled_p6x8str(61,1,"AE:");
               Oled_Print_float_num(79,1,psInductance->dir);
               oled_p6x8str(61,2,"BD:");
               Oled_Print_float_num(79,2,psInductance->dir1);
			   oled_p6x8str(0,6,"Test_Mode:");
							 if(Road_Integrals.Test_Mode==1)
								oled_p6x8str(61,6,"ON");
							 else
								 oled_p6x8str(61,6,"OFF");
               count=0;
            }
						if(!KEY_Read(BKEY1))
            {
                systick_delay_ms(50);
                if(!KEY_Read(BKEY1))
                {	
					Road_Integrals.Test_Mode = ((Road_Integrals.Test_Mode==1)?0:1);
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY1));
            }
        }
				if(flag==4)
				{
            oled_p6x8str(0,0,"NCHU FRY EGGS TEAM");
            oled_p6x8str(0,1,"GO_ROUND:");
            if(ROUND_GO_FLAG==1) oled_p6x8str(55,1,"YES");
            else oled_p6x8str(55,1,"NO");
            oled_p6x8str(0,2,"ROUND_1:");
            if(ROUND1_DIR==1) oled_p6x8str(49,2,"RIGHT");
            else oled_p6x8str(49,2,"LEFT");
            oled_p6x8str(0,3,"ROUND_2:");
            if(ROUND2_DIR==1) oled_p6x8str(49,3,"RIGHT");
            else oled_p6x8str(49,3,"LEFT");
            oled_p6x8str(0,4,"FOR?");
            if(ROUND_GO_EVERY==1) oled_p6x8str(25,4,"YES");
            else oled_p6x8str(25,4,"NO");
		    oled_p6x8str(0,5,"ROUND1_MODE:");
			if(ROUND1_MODE==1) oled_p6x8str(73,5,"BIG");
            else oled_p6x8str(73,5,"SMALL");
			oled_p6x8str(0,6,"ROUND2_MODE:");
			if(ROUND2_MODE==1) oled_p6x8str(73,6,"BIG");
            else oled_p6x8str(73,6,"SMALL");
            oled_p6x8str(112,round_flag+1,"Y");
/////////////////////////////////���ݸı��//////////////////////////////////
            if(!KEY_Read(BKEY2))
            {
               systick_delay_ms(50);
                if(!KEY_Read(BKEY2))
                {
                    switch(round_flag)
                    {
                    }
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY2));
            }
///////////////////////////////////���ݸı��//////////////////////////////////
            if(!KEY_Read(BKEY1))
            {
                systick_delay_ms(50);
                if(!KEY_Read(BKEY1))
                {
                    switch(round_flag)
                    {
                        case 0:ROUND_GO_FLAG = ((ROUND_GO_FLAG==1)?0:1);break;
                        case 1:ROUND1_DIR = ((ROUND1_DIR==1)?-1:1);break;
                        case 2:ROUND2_DIR = ((ROUND2_DIR==1)?-1:1);break;
                        case 3:ROUND_GO_EVERY = ((ROUND_GO_EVERY==1)?0:1);break;
												case 4:ROUND1_MODE = ((ROUND1_MODE==1)?0:1);break;
											  case 5:ROUND2_MODE = ((ROUND2_MODE==1)?0:1);break;
                    }
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY1));
            }
////////////////////////////////////�л�����/////////////////////////////////
            if(!KEY_Read(BKEY4))
            {
                systick_delay_ms(50);
                if(!KEY_Read(BKEY4))
                {
                    if(round_flag==5)
                        round_flag=0;
                    else
                        round_flag++;
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY4));
            }
        }
				if(flag==5)
				{
                    oled_p6x8str(0,0,"Round_Thr:");
                    oled_printf_float(61,0,Round_Threshold,5,1);
                    oled_p6x8str(0,1,"SetSpeed:");
					Oled_Print_float_num(55,1,ROUND_SPEED);
					oled_p6x8str(0,2,"Swaitdis:");
				    Oled_Print_float_num(55,2,SWAITENDISTANCE);
					oled_p6x8str(0,3,"Sstrodis:");
					Oled_Print_float_num(55,3,SSTRONGERDISTANCE);				
					oled_p6x8str(0,4,"Bwaitdis:");
					Oled_Print_float_num(55,4,BWAITENDISTANCE);
					oled_p6x8str(0,5,"Bstrodis:");
					Oled_Print_float_num(55,5,BSTRONGERDISTANCE);
					oled_p6x8str(0,6,"OutDistan:");
					Oled_Print_float_num(61,6,ROUNDCOLDCOUNT);
                    oled_p6x8str(112,option_flag,"Y");
/////////////////////////////////���ݸı��//////////////////////////////////
            if(!KEY_Read(BKEY2))
            {
               systick_delay_ms(50);
                if(!KEY_Read(BKEY2))
                {
                    switch(option_flag)
                    {
                        case 0:Round_Threshold=Round_Threshold+1000;break;
                        case 1:ROUND_SPEED=ROUND_SPEED+2;break;
						case 2:SWAITENDISTANCE=SWAITENDISTANCE+50;break;
						case 3:SSTRONGERDISTANCE=SSTRONGERDISTANCE+50;break;
						case 4:BWAITENDISTANCE=BWAITENDISTANCE+100;break;
						case 5:BSTRONGERDISTANCE=BSTRONGERDISTANCE+100;break;
						case 6:ROUNDCOLDCOUNT=ROUNDCOLDCOUNT+200;break;
                    }
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY2));
            }
///////////////////////////////////���ݸı��//////////////////////////////////
            if(!KEY_Read(BKEY1))
            {
                systick_delay_ms(50);
                if(!KEY_Read(BKEY1))
                {
                    switch(option_flag)
                    {
                        case 0:Round_Threshold=Round_Threshold-1000;break;
                        case 1:ROUND_SPEED=ROUND_SPEED-2;break;
						case 2:SWAITENDISTANCE=SWAITENDISTANCE-50;break;
						case 3:SSTRONGERDISTANCE=SSTRONGERDISTANCE-50;break;
						case 4:BWAITENDISTANCE=BWAITENDISTANCE-100;break;
						case 5:BSTRONGERDISTANCE=BSTRONGERDISTANCE-100;break;
                        case 6:ROUNDCOLDCOUNT=ROUNDCOLDCOUNT-200;break;
                    }
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY1));
            }
////////////////////////////////////�л�����/////////////////////////////////
            if(!KEY_Read(BKEY4))
            {
                systick_delay_ms(50);
                if(!KEY_Read(BKEY4))
                {
                    if(option_flag==6)
                        option_flag=0;
                    else
                        option_flag++;
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY4));
            }
        }
				if(flag==6)
				{
					oled_p6x8str(0,0,"NCHU FRY EGGS TEAM");
                    oled_p6x8str(0,1,"Speed:");
			        Oled_Print_float_num(37,1,speed_init);
			        oled_p6x8str(0,2,"Turn_Speed:");
			        Oled_Print_float_num(67,2,Turn_Speed);
			        oled_p6x8str(0,3,"Angle_MIN:");
			        Oled_Print_float_num(61,3,angle_min);
			        oled_p6x8str(0,4,"Angle_MAX:");
			        oled_printf_float(61,4,angle_max,5,1);
                    oled_p6x8str(0,5,"Sta_Speed:");
			        oled_printf_float(61,5,Road_Integrals.Start_speed,5,1);
                    oled_p6x8str(0,6,"Start_Dis:");
			        oled_printf_float(61,6,Road_Integrals.Start_distence,5,1);
                    oled_p6x8str(112,pid_option_flag+1,"Y");
/////////////////////////////////���ݸı��//////////////////////////////////
            if(!KEY_Read(BKEY2))
            {
               systick_delay_ms(50);
                if(!KEY_Read(BKEY2))
                {
                    switch(pid_option_flag)
                    {
                        case 0:speed_init+=2;break;
						case 1:Turn_Speed+=2;break;
						case 2:angle_min+=25;break;
						case 3:angle_max+=25;break;
                        case 4:Road_Integrals.Start_speed+=10;break;
                        case 5:Road_Integrals.Start_distence+=10;break;

                    }
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY2));
            }
///////////////////////////////////���ݸı��//////////////////////////////////
            if(!KEY_Read(BKEY1))
            {
                systick_delay_ms(50);
                if(!KEY_Read(BKEY1))
                {
                    switch(pid_option_flag)
                    {
                        case 0:speed_init-=2;break;
						case 1:Turn_Speed-=5;break;
						case 2:angle_min-=25;break;
						case 3:angle_max-=25;break;
                        case 4:Road_Integrals.Start_speed-=10;break;
                        case 5:Road_Integrals.Start_distence-=10;break;

                    }
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY1));
            }
////////////////////////////////////�л�����/////////////////////////////////
            if(!KEY_Read(BKEY4))
            {
                systick_delay_ms(50);
                if(!KEY_Read(BKEY4))
                {
                    if(pid_option_flag==5)
                        pid_option_flag=0;
                    else
                        pid_option_flag++;
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY4));
            }
				}
			 if(flag==7)
				{
				    oled_p6x8str(0,0,"NCHU FRY EGGS TEAM");
				    oled_p6x8str(0,1,"Three_Dir:");				
			        if(CrossRoad_Dir==-1) oled_p6x8str(61,1,"RIGHT");
                    else oled_p6x8str(61,1,"LEFT");
					oled_p6x8str(0,2,"Three_Spd:");
					Oled_Print_float_num(61,2,three_turn_speed);
					oled_p6x8str(0,3,"Three_Dis:");
					Oled_Print_float_num(61,3,CrossRoad_STOP_DISTANCE);
					oled_p6x8str(0,4,"Detect_TH:");
					Oled_Print_float_num(61,4,CrossRoad_Threshold);
                    oled_p6x8str(0,5,"Detec2_Di:");
					Oled_Print_float_num(61,5,CrossRoad_Distance);
                    oled_p6x8str(0,6,"Detec1_Di:");
					Oled_Print_float_num(61,6,CrossRoad1_Distance);
                    oled_p6x8str(0,7,"Stron_dir:");
					Oled_Print_float_num(61,7,SSTRONGCIRCLE);
                    oled_p6x8str(112,three_option_flag+1,"Y");
/////////////////////////////////���ݸı��////////////////////////////////// 2
            if(!KEY_Read(BKEY2))
            {
               systick_delay_ms(50);
                if(!KEY_Read(BKEY2))
                {
                    switch(three_option_flag)
                    {
						case 1:three_turn_speed+=2;break;
						case 2:CrossRoad_STOP_DISTANCE+=100;break;
						case 3:CrossRoad_Threshold+=100;break;
                        case 4:CrossRoad_Distance+=50;break;
                        case 5:CrossRoad1_Distance+=50;break;
                        case 6:SSTRONGCIRCLE+=1;break;
                    }
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY2));
            }
///////////////////////////////////���ݸı��////////////////////////////////// 1
            if(!KEY_Read(BKEY1))
            {
                systick_delay_ms(50);
                if(!KEY_Read(BKEY1))
                {
                    switch(three_option_flag)
                    {
						case 0:CrossRoad_Dir = ((CrossRoad_Dir==-1)?1:-1);break;
						case 1:three_turn_speed-=2;break;
						case 2:CrossRoad_STOP_DISTANCE-=100;break;
						case 3:CrossRoad_Threshold-=100;break;
                        case 4:CrossRoad_Distance-=50;break;
                        case 5:CrossRoad1_Distance-=50;break;
                        case 6:SSTRONGCIRCLE-=1;break;
                    }
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY1));
            }
////////////////////////////////////�л�����/////////////////////////////////
            if(!KEY_Read(BKEY4))
            {
                systick_delay_ms(50);
                if(!KEY_Read(BKEY4))
                {
                    if(three_option_flag==6)
                        three_option_flag=0;
                    else
                        three_option_flag++;
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY4));
            }
		    }
            if(flag==2)
			{
                oled_p6x8str(0,0,"All:");
		        oled_printf_float(24,0,Road_Integrals.All_Distance,5,1);
                Oled_Print_float_num(61,0,Road_Integrals.Three_predown);

		        oled_p6x8str(0,1,"Do1:");
		        oled_printf_float(24,1,Road_Integrals.Dowm_Dista1,5,1);
                Oled_Print_float_num(61,1,Road_Integrals.Poit1_predown);
                
		        oled_p6x8str(0,2,"Do2:");
		        oled_printf_float(24,2,Road_Integrals.Dowm_Dista2,5,1);
                Oled_Print_float_num(61,2,Road_Integrals.Poit2_predown);

		        oled_p6x8str(0,3,"Do3:");
		        oled_printf_float(24,3,Road_Integrals.Dowm_Dista3,5,1);	
                Oled_Print_float_num(61,3,Road_Integrals.Poit3_predown);

		        oled_p6x8str(0,4,"sss:");
		        oled_printf_float(24,4,Road_Integrals.Ssss_Distan,5,1);	
                Oled_Print_float_num(61,4,Road_Integrals.ssss_predown);

                oled_p6x8str(0,5,"Ram:");
		        oled_printf_float(24,5,Road_Integrals.Ramp_Distance,5,1);

                oled_p6x8str(0,6,"Ro1:");
		        oled_printf_float(24,6,Road_Integrals.Round1_Distance,5,1);

		        oled_p6x8str(0,7,"Ro2:");
		        oled_printf_float(24,7,Road_Integrals.Round2_Distance,5,1);
                oled_p6x8str(112,integal_option_flag,"Y");
///////////////////////////////�л�����////////////////////////////////  
            if(!KEY_Read(BKEY4))
            {
                systick_delay_ms(50);
                if(!KEY_Read(BKEY4))
                {
                    if(integal_option_flag==4)
                        integal_option_flag=0;
                    else
                        integal_option_flag++;
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY4));
            }
/////////////////////////////////���ݸı��////////////////////////////////// 2
            if(!KEY_Read(BKEY2))
            {
               systick_delay_ms(50);
                if(!KEY_Read(BKEY2))
                {
                    switch(integal_option_flag)
                    {
						case 0:Road_Integrals.Three_predown+=150;break;
						case 1:Road_Integrals.Poit1_predown+=250;break;
						case 2:Road_Integrals.Poit2_predown+=250;break;
                        case 3:Road_Integrals.Poit3_predown+=250;break;
                        case 4:Road_Integrals.ssss_predown+=100;break;
                    }
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY2));
            }
///////////////////////////////////���ݸı��////////////////////////////////// 1
            if(!KEY_Read(BKEY1))
            {
                systick_delay_ms(50);
                if(!KEY_Read(BKEY1))
                {
                    switch(integal_option_flag)
                    {
						case 0:Road_Integrals.Three_predown-=150;break;
						case 1:Road_Integrals.Poit1_predown-=250;break;
						case 2:Road_Integrals.Poit2_predown-=250;break;
                        case 3:Road_Integrals.Poit3_predown-=250;break;
                        case 4:Road_Integrals.ssss_predown-=100;break;
                    }
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY1));
            }
		}
        if(flag==3)
		{
                oled_p6x8str(0,0,"Thr-Speed:");
                oled_printf_float(73,0,Road_Integrals.Thre_Speed,3,1);
                oled_p6x8str(0,1,"Pre1-Speed:");
                oled_printf_float(67,1,Road_Integrals.Pre1_Speed,5,1);
                oled_p6x8str(0,2,"Pre2-Speed:");
                oled_printf_float(67,2,Road_Integrals.Pre2_Speed,5,1);
                oled_p6x8str(0,3,"Pre3-Speed:");
                oled_printf_float(67,3,Road_Integrals.Pre3_Speed,5,1);
                oled_p6x8str(0,4,"Norm-Speed:");
                oled_printf_float(67,4,Road_Integrals.Norm_Speed,5,1);
                oled_p6x8str(0,5,"Round-Speed:");
                oled_printf_float(73,5,Road_Integrals.Round_Speed,5,1);
                oled_p6x8str(112,integal_speed_option_flag,"Y");
///////////////////////////////�л�����////////////////////////////////  
            if(!KEY_Read(BKEY4))
            {
                systick_delay_ms(50);
                if(!KEY_Read(BKEY4))
                {
                    if(integal_speed_option_flag==5)
                        integal_speed_option_flag=0;
                    else
                        integal_speed_option_flag++;
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY4));
            }
/////////////////////////////////���ݸı��////////////////////////////////// 2
            if(!KEY_Read(BKEY2))
            {
               systick_delay_ms(50);
                if(!KEY_Read(BKEY2))
                {
                    switch(integal_speed_option_flag)
                    {
						case 0:Road_Integrals.Thre_Speed+=2;break;
						case 1:Road_Integrals.Pre1_Speed+=25;break;
						case 2:Road_Integrals.Pre2_Speed+=25;break;
                        case 3:Road_Integrals.Pre3_Speed+=25;break;
                        case 4:Road_Integrals.Norm_Speed+=2;break;
                        case 5:Road_Integrals.Round_Speed+=2;break;
                    }
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY2));
            }
///////////////////////////////////���ݸı��////////////////////////////////// 1
            if(!KEY_Read(BKEY1))
            {
                systick_delay_ms(50);
                if(!KEY_Read(BKEY1))
                {
                    switch(integal_speed_option_flag)
                    {
						case 0:Road_Integrals.Thre_Speed-=2;break;
						case 1:Road_Integrals.Pre1_Speed-=25;break;
						case 2:Road_Integrals.Pre2_Speed-=25;break;
                        case 3:Road_Integrals.Pre3_Speed-=25;break;
                        case 4:Road_Integrals.Norm_Speed-=2;break;
                        case 5:Road_Integrals.Round_Speed-=2;break;
                    }
                    oled_fill(0x00);
                }
                while(!KEY_Read(BKEY1));
            }
		}
    }
}

