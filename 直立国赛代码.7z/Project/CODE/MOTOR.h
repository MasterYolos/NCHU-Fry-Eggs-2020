#ifndef _MOTOR_h
#define _MOTOR_h
#define BM_RATIO            1.0         

typedef struct
{
    short duty;
    short speed;
    short speed_set;
    short speed_last;
    short acc;
    short status;
} MotorDir;

typedef struct
{
    short set;
    short now;
    short max;
    short min;
    short last;
		short turn_min;
} SPD;

typedef struct
{
    MotorDir left;
    MotorDir right;
    SPD      speed;
} Motor;

extern Motor s_motor;
extern void encoder_check(void);
extern void  MotorOUT(int LMotor_OUT, int RMotor_OUT);
#endif